<?php
use Illuminate\Database\Eloquent\Model as Eloquent;
class Saledetails extends Eloquent
{
    public $table = "sale_details";

    protected $primaryKey = 'sale_details_id';
    
}
