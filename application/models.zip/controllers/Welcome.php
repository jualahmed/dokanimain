<?php if (!defined('BASEPATH')) exit('No direct script access allowed');

class Welcome extends CI_Controller
{
	function __construct()
	{
		parent::__construct();
	}

	function update_buy_and_sale_price()
	{
		$saleProducts = $this->db->query("SELECT * FROM `sale_details` WHERE `unit_buy_price`=0 OR `general_sale_price`=0")->result();
		if ($saleProducts) {
			foreach ($saleProducts as $product) {
				$stock = $this->db->select("*")->from("bulk_stock_info")->where("product_id", $product->product_id)->get()->row();
				if ($stock) {
					$this->db->where("product_id", $product->product_id)->update('sale_details', array(
						'general_sale_price' => $stock->general_unit_sale_price,
						'unit_buy_price' => $stock->bulk_unit_buy_price,
					));
					echo 'Updated......................................<br/>';
				}
			}
		}
	}

	function update_stock_according_to_purchase()
	{
		$stocks = $this->db->select('*')
			->from('bulk_stock_info')
			->where("bulk_unit_buy_price=0")
			->get()
			->result();
		if ($stocks) {
			foreach ($stocks as $stock) {
				$purchase = $this->db->select('*')
					->from('purchase_info')
					->where('product_id', $stock->product_id)
					->order_by('purchase_doc', 'DESC')
					->get()
					->row();

				if ($purchase) {
					$this->db->where('bulk_id', $stock->bulk_id)
						->update('bulk_stock_info', array(
							'bulk_unit_buy_price' => $purchase->unit_buy_price,
							'bulk_unit_sale_price' => $purchase->bulk_unit_sale_price,
							'general_unit_sale_price' => $purchase->general_unit_sale_price,
							'last_buy_price' => $purchase->unit_buy_price,
						));
				}
			}
		}
	}
}

/* End of file welcome.php */
/* Location: ./application/controllers/welcome.php */