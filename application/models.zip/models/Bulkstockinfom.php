<?php
use Illuminate\Database\Eloquent\Model as Eloquent;
class Bulkstockinfom extends Eloquent
{
    public $table = "bulk_stock_info";
    protected $primaryKey = 'bulk_id';

    
}
?>