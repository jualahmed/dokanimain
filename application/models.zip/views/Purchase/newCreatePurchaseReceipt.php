<option selected="selected"></option>
<?php foreach($purchase_receipt_info as $ind => $tmp){?>
<option value="<?php echo $ind; ?>"><?php echo $tmp; ?></option><?php }?>