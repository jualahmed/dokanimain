	  	<div class="page-footer">
    		<div class="part70P"> 
				<div class="developPart">
					<div class ="pos_top_header_fotter" > Thank You For Being With Us.</div>
					<div class ="pos_top_header_fotter">Software Developed By: <b>IT Lab Solutions Ltd.</b> Call: +8801842485222</div>
				</div>
			</div>
  		</div>
	</body>
</html>	
