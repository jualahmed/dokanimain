<?php $this -> load -> view('include/header_web2'); ?>
<center><h2>Order Status</h2>
<p class="ord-succ">Your order has been placed successfully.</p>
<a href="<?php echo base_url();?>web/index">Back to Home</a>
</center>

<br>
<br>
<?php $this -> load -> view('include/footer_web'); ?>