<?php
use Illuminate\Database\Eloquent\Model as Eloquent;
class Dailystatementm extends Eloquent
{
    public $table = "daily_statement";
    
}
