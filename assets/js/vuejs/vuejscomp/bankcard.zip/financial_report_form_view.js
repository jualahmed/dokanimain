$(document).ready(function() {
		$("#reset_btn").click(function(event) {
		event.preventDefault();
				$('#datep').val('');
				$('#datepp').val('');
				$('#datep2').val('');
		});
	});